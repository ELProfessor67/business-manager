import React from 'react'

const page = () => {
  return (
    <div>
      <a href="https://www.linkedin.com/feed/?shareActive=true&text=This is my text! https://ogp.me/ %23NewPost">share
      </a>
    </div>
  )
}

export default page