import React from 'react'

const page = () => {
  return (
    <div>Mail Page</div>
  )
}

export default page