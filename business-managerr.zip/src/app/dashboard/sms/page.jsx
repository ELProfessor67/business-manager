import React from 'react'

const page = () => {
  return (
    <div>SMS Page</div>
  )
}

export default page